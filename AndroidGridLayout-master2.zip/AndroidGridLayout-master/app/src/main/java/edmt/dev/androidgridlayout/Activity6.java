package edmt.dev.androidgridlayout;

import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Activity6 extends AppCompatActivity {
    private ListView mListView;
    private Map<String,String> listIndexToDatabaseId;
    DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
        myDB = new DatabaseHelper(this);
        mListView = (ListView) findViewById(R.id.listView);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(myDB.removeItem(listIndexToDatabaseId.get(String.valueOf(i)))){
                    ArrayList<String> theList = new ArrayList<>();
                    Cursor data = myDB.getListContents();
                    listIndexToDatabaseId = new HashMap<>();
                    int counter = 0;
                    if(data.getCount() == 0){
                        Toast.makeText(Activity6.this, "Baza jest pusta", Toast.LENGTH_LONG).show();
                    }else{
                        while(data.moveToNext()){
                            listIndexToDatabaseId.put(String.valueOf(counter),data.getString(0));
                            theList.add(data.getString(1));
                            counter++;
                        }
                    }
                    ListAdapter listAdapter = new ArrayAdapter<>(Activity6.this, android.R.layout.simple_list_item_1,theList);
                    mListView.setAdapter(listAdapter);
                    mListView.refreshDrawableState();
                }else {
                    Toast.makeText(Activity6.this, "Coś poszło nie tak :(", Toast.LENGTH_LONG).show();
                }

            }
        });


        ArrayList<String> theList = new ArrayList<>();
        Cursor data = myDB.getListContents();
        listIndexToDatabaseId = new HashMap<>();
        int counter = 0;
        if(data.getCount() == 0){
            Toast.makeText(Activity6.this, "Baza byla pusta", Toast.LENGTH_LONG).show();
        }else{
            while(data.moveToNext()){
                listIndexToDatabaseId.put(String.valueOf(counter),data.getString(0));
                theList.add(data.getString(1));
                counter++;
            }
            ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,theList);
            mListView.setAdapter(listAdapter);
        }
    }

}
