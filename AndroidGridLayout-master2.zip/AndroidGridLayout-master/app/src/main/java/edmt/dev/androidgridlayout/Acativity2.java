package edmt.dev.androidgridlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Acativity2 extends AppCompatActivity {

    private TextView mTextViewResult;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acativity2);

        mTextViewResult = findViewById(R.id.text_view_results);
        Button button = findViewById(R.id.button_parse);

        mQueue = Volley.newRequestQueue(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonParse();
            }
        });
    }

    private void jsonParse(){
        String url = "https://api.myjson.com/bins/ayylj";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("dogs");

                            for (int i = 0; i < jsonArray.length(); i++){
                                JSONObject dog = jsonArray.getJSONObject(i);

                                int ID = dog.getInt("ID");
                                String Imię = dog.getString("Imię");
                                String Rasa = dog.getString("Rasa");
                                int Wiek = dog.getInt("Wiek");
                                String Usposobienie = dog.getString("Usposobienie");

                                mTextViewResult.append(String.valueOf(ID) + "," + Imię + "," + Rasa + "," + String.valueOf(Wiek) + "," + Usposobienie + "\n\n");

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            error.printStackTrace();
            }
        });
    mQueue.add(request);
    };
}


