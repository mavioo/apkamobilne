package ay3524.com.popularmovies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OAutorze extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oautorze);
    }
}
