package ay3524.com.popularmovies;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;

import ay3524.com.popularmovies.activity.MainActivity;


public class PierwszaStrona extends AppCompatActivity {

    private Button Mapa;
    private Button ListaKsiazek;
    private Button UsunKsiazke;
    private Button DodajKsiazke;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pierwsza_strona);


        DodajKsiazke = (Button) findViewById(R.id.DodajKsiazke);
        DodajKsiazke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               openP();
            }
        });

        Mapa = (Button)findViewById(R.id.Mapa);
        Mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOA();
            }
        });


        UsunKsiazke = (Button)findViewById(R.id.UsunKsiazke);
        UsunKsiazke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNB();
            }
        });






    }
    public void FB(View View){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.facebook.com"));
        startActivity(browserIntent);
    }
    public void openP(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    public void openNB() {
        Intent intent = new Intent(this, NajblizszeKina.class);
        startActivity(intent);
    }
    public void openOA() {
        Intent intent = new Intent(this, OAutorze.class);
        startActivity(intent);
    }

}
