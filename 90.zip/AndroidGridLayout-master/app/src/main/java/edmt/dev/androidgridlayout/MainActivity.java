package edmt.dev.androidgridlayout;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button Autor;
    private Button Mapa;
    private Button ListaKsiazek;
    private Button UsunKsiazke;
    private Button DodajKsiazke;


    GridLayout mainGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainGrid = (GridLayout) findViewById(R.id.mainGrid);

        //Set Event
        setSingleEvent(mainGrid);
        //setToggleEvent(mainGrid);

        Autor = (Button) findViewById(R.id.Autor);
        Autor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAcativity2();
            }
        });


        Mapa = (Button)findViewById(R.id.Mapa);
        Mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAcativity4();
            }
        });

        ListaKsiazek = (Button)findViewById(R.id.ListaKsiazek);
        ListaKsiazek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAcativity5();
            }
        });

        UsunKsiazke = (Button)findViewById(R.id.UsunKsiazke);
        UsunKsiazke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity6();
            }
        });

        DodajKsiazke = (Button)findViewById(R.id.DodajKsiazke);
        DodajKsiazke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAcativity7();
            }
        });

    }

    public void openAcativity2(){
        Intent intent = new Intent(this,Acativity2.class);
                startActivity(intent);
    }
    public void FB(View View){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.facebook.com"));
        startActivity(browserIntent);
    }

    public void openAcativity4(){
        Intent intent3 = new Intent(this, Activity4.class);
            startActivity(intent3);
    }

    public void openAcativity5(){
        Intent intent4 = new Intent(this, Activity5.class);
        startActivity(intent4);
    }

    public void openActivity6(){
        Intent intent5 = new Intent(this, Activity6.class);
        startActivity(intent5);
    }

    public void openAcativity7(){
        Intent intent6 = new Intent(this, Activity7.class);
        startActivity(intent6);
    }

    public void open(View View){
        Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com"));
        startActivity(browserIntent);
    }
    private void setToggleEvent(GridLayout mainGrid) {
        //Loop all child item of Main Grid
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            //You can see , all child item is CardView , so we just cast object to CardView
            final CardView cardView = (CardView) mainGrid.getChildAt(i);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cardView.getCardBackgroundColor().getDefaultColor() == -1) {
                        //Change background color
                        cardView.setCardBackgroundColor(Color.parseColor("#FF6F00"));
                        Toast.makeText(MainActivity.this, "State : True", Toast.LENGTH_SHORT).show();

                    } else {
                        //Change background color
                        cardView.setCardBackgroundColor(Color.parseColor("#FFFFFF"));
                        Toast.makeText(MainActivity.this, "State : False", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void setSingleEvent(GridLayout mainGrid) {
        //Loop all child item of Main Grid
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            //You can see , all child item is CardView , so we just cast object to CardView
            CardView cardView = (CardView) mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(MainActivity.this,ActivityOne.class);
                    intent.putExtra("info","This is activity from card item index  "+finalI);
                    startActivity(intent);

                }
            });
        }
    }
}
